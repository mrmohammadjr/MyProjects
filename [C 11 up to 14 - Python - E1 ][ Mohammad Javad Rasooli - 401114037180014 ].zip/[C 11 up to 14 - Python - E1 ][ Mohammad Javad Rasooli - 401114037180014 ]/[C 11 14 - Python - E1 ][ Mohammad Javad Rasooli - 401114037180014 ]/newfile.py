inth = input('enter hours :')
intr = input('enter rate :')

hours = int(inth)
rate = int(intr)

if hours > 40 :
	time = float(hours) - 40
else :
	time = 0
	
money = 0.5 * float(rate) * time
cash = float(hours) * float(rate) + money

print(cash)