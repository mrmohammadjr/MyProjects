#1
print(123)
print(98.6)
print("hello")
#2
a = 45.0
b = 12.50
c = a * b
print(c)
#3
x = 12
x = 100
print(x)
#4
num = 2
num = num * 2
print(num)
#5
j = 23
k = j % 5
print(k)
#6
l = 1+2**3/4*5
print(l)
#7
text = 'mohammad ' + 'javad'
print(text)
#8
xx = 1
print(type(xx))
#9
yy = 1.5
print(type(yy))
#10
tt = 'hello'
print(type(tt))
#11
sval = '321'
n = int(sval)
print(n)
#12
txt = input('enter your name :')
print('hello ' + txt)
#13
inp = input('europe floor?')
usf = int(inp) + 1
print('US floor',usf)
#14
hrs = input("Enter Hour:")
rate = input("Eenter Rate per Hour:")
pay = float(hrs) * float(rate)
print ("Pay:", pay)		